# Вспомогательные функции

def generate_link():
    return 'https://example.com'